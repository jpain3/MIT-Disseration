Vignette files will be placed here
